#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>

@interface GeocoderViewController : UIViewController <GMSMapViewDelegate>

@end
