#import <UIKit/UIKit.h>

@interface FitBoundsViewController : UIViewController

@end
