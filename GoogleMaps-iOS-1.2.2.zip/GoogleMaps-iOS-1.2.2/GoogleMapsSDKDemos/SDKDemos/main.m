#import <UIKit/UIKit.h>

#import "SDKDemos/SDKDemosAppDelegate.h"

int main(int argc, char *argv[]) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass([SDKDemosAppDelegate class]));
  }
}
